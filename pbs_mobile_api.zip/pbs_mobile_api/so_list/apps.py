from django.apps import AppConfig


class SoListConfig(AppConfig):
    name = 'so_list'
